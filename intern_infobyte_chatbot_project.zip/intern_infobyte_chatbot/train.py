import json
import os
from pathlib import Path

from chatterbot import ChatBot
from chatterbot.tagging import LowercaseTagger
from chatterbot.trainers import ListTrainer

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "chatbot.sqlite3"
SAMPLE_PATH = BASE_DIR / "data" / "sample_conversations.json"

# Create a fresh database when this script is explicitly run with RESET_DB=1.
if os.getenv("RESET_DB") == "1" and DB_PATH.exists():
    DB_PATH.unlink()

bot = ChatBot(
    "Infobyte Assistant",
    storage_adapter="chatterbot.storage.SQLStorageAdapter",
    database_uri=f"sqlite:///{DB_PATH}",
    tagger=LowercaseTagger,
    logic_adapters=["chatterbot.logic.BestMatch"],
    read_only=False,
)

trainer = ListTrainer(bot)

with SAMPLE_PATH.open("r", encoding="utf-8") as f:
    conversations = json.load(f)

for conversation in conversations:
    if len(conversation) >= 2:
        trainer.train(conversation)

print(f"Training complete. Database: {DB_PATH}")
print(f"Seed conversations trained: {len(conversations)}")
