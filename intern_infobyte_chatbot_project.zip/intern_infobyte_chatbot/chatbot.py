from pathlib import Path
from threading import Lock

from chatterbot import ChatBot
from chatterbot.tagging import LowercaseTagger

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "chatbot.sqlite3"

# LowercaseTagger uses spaCy internally without requiring a large language model.
# This keeps the project lightweight while still using spaCy for NLP processing.
bot = ChatBot(
    "Infobyte Assistant",
    storage_adapter="chatterbot.storage.SQLStorageAdapter",
    database_uri=f"sqlite:///{DB_PATH}",
    tagger=LowercaseTagger,
    logic_adapters=[
        "chatterbot.logic.BestMatch",
    ],
    read_only=True,
)

_bot_lock = Lock()


def get_bot_response(message: str) -> str:
    """Return the best response learned by ChatterBot."""
    with _bot_lock:
        response = bot.get_response(message)
    text = str(response).strip()

    if not text:
        return "I am still learning. Could you rephrase that?"

    return text
