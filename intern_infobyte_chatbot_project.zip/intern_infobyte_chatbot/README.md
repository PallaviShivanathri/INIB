# Intern Infobyte – Task 2: NLP Chatbot

A complete student project that builds a web-based conversational chatbot using:

- Python
- ChatterBot
- NLTK
- spaCy
- Flask
- HTML, CSS and JavaScript
- Cornell Movie-Dialogs Corpus for optional large-scale training
- Heroku-compatible deployment

## 1. Project structure

```text
intern_infobyte_chatbot/
├── app.py
├── chatbot.py
├── nlp_utils.py
├── train.py
├── train_cornell.py
├── setup_nlp.py
├── requirements.txt
├── runtime.txt
├── Procfile
├── test_app.py
├── data/
│   └── sample_conversations.json
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── script.js
└── scripts/
```

The SQLite database is generated after training and is intentionally ignored by Git.

## 2. Install Python

Use Python 3.12 for a straightforward setup.

Check:

```bash
python --version
```

## 3. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

## 4. Install dependencies

```bash
pip install -r requirements.txt
python setup_nlp.py
```

## 5. Train the initial chatbot

```bash
python train.py
```

This trains the bot with the included starter conversations.

## 6. Run the website

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## 7. Train with Cornell Movie-Dialogs Corpus

The official Cornell corpus contains 220,579 conversational exchanges and 304,713 utterances.

Start with a manageable subset:

```bash
python train_cornell.py --download --limit 5000
```

For a larger experiment:

```bash
python train_cornell.py --limit 20000
```

Training the entire corpus can take significantly longer and requires more storage and memory, so record the subset size and training time in your project report.

## 8. Run tests

```bash
python -m unittest test_app.py
```

## 9. Deploy to Heroku

Install and log in to the Heroku CLI, then:

```bash
git init
git add .
git commit -m "Build NLP chatbot"
heroku create your-unique-chatbot-name
git push heroku main
heroku open
```

If your Git branch is `master`, use:

```bash
git push heroku master
```

The `Procfile` starts Gunicorn with:

```text
web: gunicorn app:app --workers 1 --threads 4 --timeout 120
```

### Important deployment note

Heroku dynos have an ephemeral filesystem. For a student demo, a SQLite database can work as part of the deployed application, but persistent production storage should use a database service. Do not depend on runtime-created SQLite data surviving dyno replacement.

## 10. Recommended 1-month plan

### Week 1 – Environment and chatbot foundation
- Install Python and dependencies.
- Learn ChatterBot basics.
- Build the first conversational bot.
- Add starter training conversations.
- Test responses.

### Week 2 – NLP
- Add NLTK tokenization and text normalization.
- Add spaCy text processing.
- Integrate NLP analysis into the Flask API.
- Study response matching and confidence.

### Week 3 – Dataset and web UI
- Download Cornell Movie-Dialogs Corpus.
- Parse movie lines and conversation IDs.
- Train using a controlled subset.
- Build the HTML/CSS/JavaScript interface.
- Add error handling and API validation.

### Week 4 – Testing, deployment and documentation
- Run unit tests.
- Measure response latency.
- Compare results before and after training.
- Deploy to Heroku.
- Prepare screenshots, GitHub repository and final report.
- Record limitations and future improvements.

## 11. Suggested evaluation

Measure at least:

| Metric | What to record |
|---|---|
| Response latency | Average API response time |
| Successful responses | Number of meaningful replies / test questions |
| Fallback rate | Questions producing weak/unhelpful responses |
| Training size | Number of conversations/utterances |
| API reliability | Successful requests / total requests |

Use a fixed test set, for example 20–50 questions, so the comparison is repeatable.

## 12. Features demonstrated

1. Conversational response generation with ChatterBot.
2. NLP preprocessing with NLTK.
3. Text processing with spaCy.
4. Training from custom conversation data.
5. Optional training from Cornell Movie-Dialogs Corpus.
6. REST-style Flask `/api/chat` endpoint.
7. Responsive web interface using HTML/CSS/JavaScript.
8. Unit tests and health endpoint.
9. Heroku/Gunicorn deployment configuration.

## 13. Limitations

This is a retrieval/matching-oriented chatbot, not a modern generative LLM. Its answers depend strongly on the quality and coverage of its training conversations. Movie-dialogue data can also contain informal or context-dependent language. These limitations should be discussed in the final report.

## 14. Future enhancements

- Add a larger and domain-specific dataset.
- Add conversation memory using sessions.
- Store persistent conversations in PostgreSQL.
- Add authentication.
- Add sentiment analysis.
- Add speech input/output.
- Add a transformer/LLM layer for more natural responses.
- Add monitoring and analytics.
