import nltk

# Download only the tokenizer data needed by this project.
nltk.download("punkt")
try:
    nltk.download("punkt_tab")
except Exception:
    pass

print("NLP resources are ready.")
