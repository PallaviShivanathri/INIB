# Final Submission Checklist

Before submitting the Intern Infobyte task:

- [ ] Python project runs locally.
- [ ] `python train.py` completes successfully.
- [ ] `python app.py` opens the chatbot.
- [ ] `/health` returns status OK.
- [ ] `/api/chat` responds to messages.
- [ ] NLTK preprocessing works.
- [ ] spaCy is imported and used.
- [ ] ChatterBot is used for response generation.
- [ ] Cornell corpus training has been demonstrated.
- [ ] At least 20 test questions have been evaluated.
- [ ] Average response latency has been recorded.
- [ ] Screenshots of the working chatbot have been taken.
- [ ] GitHub repository is updated.
- [ ] Heroku deployment has been tested.
- [ ] Final report has actual measured results.
- [ ] Do not claim metrics you did not measure.
