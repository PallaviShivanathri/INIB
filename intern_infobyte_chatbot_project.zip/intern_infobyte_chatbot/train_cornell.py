"""
Download and train from the Cornell Movie-Dialogs Corpus.

The official corpus contains 220,579 conversational exchanges and
304,713 utterances. This script intentionally supports a --limit option
so a student can start with a manageable subset and scale up later.

Usage:
    python train_cornell.py --download --limit 5000
    python train_cornell.py --limit 20000
"""
import argparse
import re
import urllib.request
import zipfile
from pathlib import Path

from chatterbot import ChatBot
from chatterbot.tagging import LowercaseTagger
from chatterbot.trainers import ListTrainer

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
ZIP_PATH = DATA_DIR / "cornell_movie_dialogs_corpus.zip"
EXTRACT_DIR = DATA_DIR / "cornell_movie_dialogs_corpus"
DB_PATH = DATA_DIR / "chatbot.sqlite3"

CORPUS_URL = "https://www.cs.cornell.edu/~cristian/data/cornell_movie_dialogs_corpus.zip"


def download():
    DATA_DIR.mkdir(exist_ok=True)
    if ZIP_PATH.exists():
        print("Corpus archive already exists.")
        return
    print("Downloading official Cornell Movie-Dialogs Corpus...")
    urllib.request.urlretrieve(CORPUS_URL, ZIP_PATH)
    print("Download complete.")


def extract():
    if EXTRACT_DIR.exists():
        return
    with zipfile.ZipFile(ZIP_PATH, "r") as zf:
        zf.extractall(DATA_DIR)


def locate(name):
    matches = list(DATA_DIR.rglob(name))
    if not matches:
        raise FileNotFoundError(name)
    return matches[0]


def load_pairs(limit):
    lines_path = locate("movie_lines.txt")
    conversations_path = locate("movie_conversations.txt")

    line_map = {}
    with lines_path.open("r", encoding="iso-8859-1") as f:
        for row in f:
            parts = row.rstrip("\n").split(" +++$+++ ")
            if len(parts) == 5:
                line_map[parts[0]] = parts[4].strip()

    conversations = []
    with conversations_path.open("r", encoding="iso-8859-1") as f:
        for row in f:
            parts = row.rstrip("\n").split(" +++$+++ ")
            if len(parts) != 4:
                continue

            ids = re.findall(r"L\d+", parts[3])
            utterances = [line_map[i] for i in ids if i in line_map]

            # ChatterBot learns from alternating statements.
            # Limit each conversation to avoid oversized training calls.
            if len(utterances) >= 2:
                cleaned = [
                    u.replace("\t", " ").strip()
                    for u in utterances
                    if 1 < len(u) <= 500
                ]
                if len(cleaned) >= 2:
                    conversations.append(cleaned)
                    if len(conversations) >= limit:
                        break

    return conversations


def train(conversations):
    bot = ChatBot(
        "Infobyte Assistant",
        storage_adapter="chatterbot.storage.SQLStorageAdapter",
        database_uri=f"sqlite:///{DB_PATH}",
        tagger=LowercaseTagger,
        logic_adapters=["chatterbot.logic.BestMatch"],
        read_only=False,
    )
    trainer = ListTrainer(bot)

    for i, conversation in enumerate(conversations, start=1):
        trainer.train(conversation)
        if i % 100 == 0:
            print(f"Trained {i}/{len(conversations)} conversations")

    print("Cornell training completed.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--limit", type=int, default=5000)
    args = parser.parse_args()

    if args.download or not ZIP_PATH.exists():
        download()
    extract()

    conversations = load_pairs(max(1, args.limit))
    print(f"Loaded {len(conversations)} Cornell conversations.")
    train(conversations)
