# INTERN INFOBYTE – ARTIFICIAL INTELLIGENCE
## TASK 2: CREATE A CHATBOT

### Project Title
**NLP-Based Conversational Chatbot Using Python, ChatterBot, NLTK and spaCy**

---

## 1. Abstract

This project implements a web-based conversational chatbot using Python and the ChatterBot library. The system accepts natural-language messages from a user, processes the text using NLP techniques, and selects an appropriate response from the chatbot's trained knowledge base. NLTK is used for tokenization and text normalization, while spaCy is used as the NLP processing framework. The chatbot can be trained with custom conversations and can also be trained using the Cornell Movie-Dialogs Corpus. A Flask backend provides the chatbot API and an HTML/CSS/JavaScript frontend provides a simple user interface. The final application can be deployed using Gunicorn and Heroku.

---

## 2. Problem Statement

Traditional rule-based chat interfaces require developers to manually define a large number of possible user inputs and responses. The goal of this project is to create a conversational system that can learn response patterns from dialogue data and provide suitable responses to natural-language user queries.

---

## 3. Objectives

- Build a chatbot using Python and ChatterBot.
- Apply NLP concepts to user messages.
- Use NLTK for tokenization and normalization.
- Use spaCy for text processing.
- Train the chatbot using conversational data.
- Use the Cornell Movie-Dialogs Corpus as an optional large training source.
- Develop a web interface using HTML, CSS and JavaScript.
- Expose chatbot functionality through a Flask API.
- Test and deploy the application.

---

## 4. Technologies Used

| Technology | Purpose |
|---|---|
| Python | Core programming language |
| ChatterBot | Conversational response engine |
| NLTK | Tokenization and preprocessing |
| spaCy | NLP processing |
| Flask | Backend web framework |
| HTML | Web page structure |
| CSS | Interface design |
| JavaScript | User interaction and API calls |
| SQLite | Local chatbot knowledge storage |
| Gunicorn | Production WSGI server |
| Heroku | Cloud deployment |

---

## 5. System Architecture

```text
User
  |
  v
HTML/CSS/JavaScript Chat Interface
  |
  v
Flask /api/chat
  |
  +--------------------+
  |                    |
  v                    v
NLTK + spaCy       ChatterBot
NLP processing     Response matching
  |                    |
  +---------+----------+
            |
            v
       Response
            |
            v
          User
```

---

## 6. Working Methodology

### Step 1: User input
The user enters a natural-language question into the web interface.

### Step 2: API request
JavaScript sends the message to the Flask `/api/chat` endpoint.

### Step 3: NLP preprocessing
The message is normalized and tokenized. spaCy provides the NLP processing layer used by the application.

### Step 4: ChatterBot response generation
ChatterBot searches its trained knowledge base and uses its response-selection logic to select a suitable response.

### Step 5: Response delivery
The selected response is returned as JSON and displayed in the chat interface.

---

## 7. Dataset

The project supports the Cornell Movie-Dialogs Corpus. The corpus contains movie-script conversations and metadata. It contains 220,579 conversational exchanges and 304,713 utterances.

Because training the complete corpus may be resource-intensive on a student laptop, the project provides a configurable `--limit` parameter. This allows experiments with 5,000, 10,000, 20,000 or more conversations.

---

## 8. Dataset Processing

The Cornell data contains:
- movie line IDs
- character IDs
- movie IDs
- character names
- utterance text
- conversation sequences

The `train_cornell.py` program:
1. Downloads the corpus.
2. Extracts the archive.
3. Reads movie lines.
4. Maps line IDs to utterances.
5. Reads conversation sequences.
6. Reconstructs conversations.
7. Removes invalid/oversized entries.
8. Sends conversations to ChatterBot's ListTrainer.

---

## 9. Web Application

The interface contains:
- chatbot title and status
- scrollable conversation window
- user input box
- Send button
- suggested questions
- responsive mobile layout

The frontend communicates asynchronously with Flask using the Fetch API.

---

## 10. API

### POST `/api/chat`

Request:

```json
{
  "message": "What is NLP?"
}
```

Response:

```json
{
  "response": "NLP stands for Natural Language Processing...",
  "analysis": {
    "normalized": "what is nlp?",
    "token_count": 4,
    "tokens": ["what", "is", "nlp", "?"],
    "entities": []
  }
}
```

### GET `/health`

Returns a simple service health response.

---

## 11. Testing Plan

Test categories:
- greetings
- NLP questions
- ChatterBot questions
- unknown questions
- empty input
- API errors
- mobile interface
- deployment health check

Example test cases:

| Input | Expected result |
|---|---|
| Hello | Greeting response |
| What is NLP? | NLP-related response |
| What is Python? | Python-related response |
| Thank you | Polite response |
| Empty input | HTTP 400 |
| Random unsupported question | Graceful response/fallback |

---

## 12. Performance Evaluation

During Week 4, record actual results instead of inventing values.

Recommended experiment:

```text
Training set: 5,000 conversations
Test questions: 50
Average response latency: ______ ms
Useful responses: ______ / 50
Fallback/weak responses: ______ / 50
```

Repeat with 10,000 and 20,000 conversations and compare the results.

---

## 13. Advantages

- Simple architecture.
- Easy to understand for a beginner/intermediate Python student.
- Uses real conversational data.
- Includes an actual web interface.
- Easy to extend.
- Demonstrates practical NLP concepts.

---

## 14. Limitations

- ChatterBot response quality depends on training data.
- Movie dialogue can be context-dependent.
- The chatbot is not equivalent to a modern generative AI model.
- SQLite is not ideal for persistent production deployment on ephemeral cloud filesystems.
- Increasing the dataset increases training time and storage requirements.

---

## 15. Future Scope

- Add domain-specific training data.
- Add sentiment analysis.
- Add conversation memory.
- Add PostgreSQL persistence.
- Add authentication.
- Add voice input and speech output.
- Add transformer-based semantic retrieval.
- Add a modern LLM as an optional response generator.
- Add analytics for user queries and response quality.

---

## 16. Conclusion

The project demonstrates how Python-based NLP tools can be combined to build a functional conversational chatbot. ChatterBot provides the conversational response engine, NLTK supports preprocessing, spaCy provides NLP processing, Flask exposes the backend API, and HTML/CSS/JavaScript provide the user interface. The project also demonstrates dataset preparation, training, testing and cloud deployment, satisfying the major requirements of the Intern Infobyte Task 2.

---

## 17. References

1. ChatterBot documentation: https://docs.chatterbot.us/
2. ChatterBot source code: https://github.com/gunthercox/ChatterBot
3. Cornell Movie-Dialogs Corpus: https://www.cs.cornell.edu/~cristian/Cornell_Movie-Dialogs_Corpus.html
4. Flask documentation: https://flask.palletsprojects.com/
5. NLTK documentation: https://www.nltk.org/
6. spaCy documentation: https://spacy.io/
7. Heroku Python documentation: https://devcenter.heroku.com/categories/python-support
