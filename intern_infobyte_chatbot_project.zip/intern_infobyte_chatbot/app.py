from flask import Flask, render_template, request, jsonify
from chatbot import get_bot_response
from nlp_utils import analyze_text

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()

    if not message:
        return jsonify({"error": "Please enter a message."}), 400

    response = get_bot_response(message)
    analysis = analyze_text(message)

    return jsonify({
        "response": response,
        "analysis": analysis
    })


@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "Intern Infobyte NLP Chatbot"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(__import__("os").environ.get("PORT", 5000)), debug=True)
