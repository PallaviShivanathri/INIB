import re

import nltk
import spacy

# NLTK is used for tokenization/normalization.
# The small tokenizer resource is downloaded by setup_nlp.py.
try:
    _nlp = spacy.blank("en")
except Exception:
    _nlp = None


def normalize_text(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    return text


def tokenize(text: str):
    """Tokenize text with NLTK, with a safe regex fallback."""
    try:
        return nltk.word_tokenize(text)
    except LookupError:
        return re.findall(r"\b\w+\b|[^\w\s]", text)


def analyze_text(text: str) -> dict:
    """Small NLP demonstration used by the web API."""
    normalized = normalize_text(text)
    tokens = tokenize(normalized)

    entities = []
    if _nlp is not None:
        doc = _nlp(text)
        entities = [
            {"text": ent.text, "label": ent.label_}
            for ent in doc.ents
        ]

    return {
        "normalized": normalized,
        "token_count": len(tokens),
        "tokens": tokens[:30],
        "entities": entities,
    }
